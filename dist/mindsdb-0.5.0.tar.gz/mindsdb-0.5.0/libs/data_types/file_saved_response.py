class FileSavedResponse:

    def __init__(self, file_id, path):
        self.file_id = file_id
        self.path = path