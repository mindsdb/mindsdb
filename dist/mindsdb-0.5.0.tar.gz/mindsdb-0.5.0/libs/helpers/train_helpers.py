def saveModel(model_object, mongo_collection, grid_fs_pointer):

    pass