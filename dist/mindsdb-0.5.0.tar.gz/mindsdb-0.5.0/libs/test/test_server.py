import _mysql

cnx = _mysql.connect(user='root', passwd='test1',
                                host='127.0.0.1')